# production credentials
user = "postgres"
password = "Hien3045"

# test credentials
test_user = "postgres"
test_password = "Hien3045"