# rename this file to "config.py"
# production credentials, used in "models.py"
user = "postgres"
password = "password"

# test credentials, used in "test_flaskr.py"
test_user = "postgres"
test_password = "password"